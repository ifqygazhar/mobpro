package com.alfinn.listhewan;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.CompositePageTransformer;
import androidx.viewpager2.widget.MarginPageTransformer;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;
import android.view.View;

import com.alfinn.listhewan.adapter.AnimalListAdapter;
import com.alfinn.listhewan.models.Animal;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ViewPager2 viewPager;
    private AnimalListAdapter sliderAdapter;
    private List<Animal> animals;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        viewPager = findViewById(R.id.viewPager);

        animals = generateAnimalData();
        sliderAdapter = new AnimalListAdapter(animals,this);

        viewPager.setAdapter(sliderAdapter);
        viewPager.setClipToPadding(false);
        viewPager.setClipChildren(false);
        viewPager.setOffscreenPageLimit(3);
        viewPager.getChildAt(0).setOverScrollMode(View.OVER_SCROLL_NEVER);
        CompositePageTransformer compositePageTransformer = new CompositePageTransformer();

        compositePageTransformer.addTransformer(new MarginPageTransformer(40));
        compositePageTransformer.addTransformer(new ViewPager2.PageTransformer() {
            @Override
            public void transformPage(@NonNull View page, float position) {
                float r = 1 - Math.abs(position);
                page.setScaleY(0.90f + r * 0.04f);
            }
        });

        viewPager.setPageTransformer(compositePageTransformer);



    }

    private List<Animal> generateAnimalData() {
        String gajah,singa,koala,monyet;
        gajah = "Gajah adalah mamalia raksasa yang ditemukan di Asia dan Afrika. Dikenal karena tubuhnya yang besar, gadingnya yang menonjol, dan belalainya yang panjang, gajah adalah salah satu hewan darat terbesar di dunia. Mereka memiliki kecerdasan yang luar biasa dan dapat menunjukkan perilaku kompleks, termasuk empati, kesetiaan terhadap sesama anggota kawanan, dan kemampuan untuk belajar dengan cepat. Habitat alaminya termasuk hutan, savana, dan padang rumput, di mana mereka berperan penting dalam ekosistem sebagai agen pemangsa dan pemakan tumbuhan. Sayangnya, gajah menghadapi ancaman serius dari perburuan ilegal untuk gadingnya, kehilangan habitat, dan konflik dengan manusia.";
        singa = "Singa adalah hewan karnivora besar dalam keluarga Felidae. Dikenal dengan nama Latinnya, Panthera leo, singa adalah salah satu dari \"The Big Five\" di Afrika dan simbol kekuatan dan kekuasaan di banyak budaya. Dengan ciri khas berupa rambut berwarna cokelat-kuning, singa jantan dikenali dengan janggut dan bulu tebal di leher, sedangkan singa betina cenderung lebih ramping. Singa hidup dalam kelompok sosial yang disebut kawanan, di mana mereka membangun hierarki yang kompleks dan melakukan perburuan bersama. Habitat asli mereka meliputi padang rumput Afrika, savana, hutan, dan semak belukar. Meskipun singa memiliki reputasi sebagai pemburu utama, populasi mereka telah menurun secara signifikan akibat hilangnya habitat, konflik dengan manusia, dan perburuan ilegal. Upaya konservasi dilakukan untuk melindungi dan memperbarui populasi singa di alam liar.";
        koala = "Koala adalah marsupial yang ditemukan di Australia. Meskipun disebut \"koala beruang,\" mereka sebenarnya bukan beruang tetapi marsupial. Koala terkenal karena makanan utamanya adalah daun eukaliptus, yang juga merupakan habitat mereka. Dengan bulu lebat dan telinga besar yang memungkinkan mereka mendengar dengan baik, koala adalah contoh keindahan alam Australia yang unik. Namun, populasi koala telah menurun secara signifikan karena hilangnya habitat alami, serangan penyakit, dan ancaman dari perubahan iklim. Upaya konservasi telah dilakukan untuk memastikan kelangsungan hidup mereka di alam liar.";
        monyet = "Monyet adalah mamalia primata yang terkenal karena kecerdasan, fleksibilitas perilaku, dan kemampuan mereka untuk beradaptasi dengan lingkungan mereka. Mereka termasuk dalam famili Primat, yang juga mencakup simpanse, gorila, dan manusia.";

        List<Animal> animals = new ArrayList<>();
        animals.add(new Animal("Singa",singa, R.drawable.singa));
        animals.add(new Animal("Gajah", gajah, R.drawable.gajah));
        animals.add(new Animal("Koala", koala, R.drawable.koala));
        animals.add(new Animal("Monyet", monyet, R.drawable.monyet));
        return animals;
    }



    // Metode yang akan dipanggil ketika tombol kiri ditekan
    public void onPreviousButtonClicked(View view) {
        int currentPosition = viewPager.getCurrentItem();
        viewPager.setCurrentItem(currentPosition - 1, true);
    }

    // Metode yang akan dipanggil ketika tombol kanan ditekan
    public void onNextButtonClicked(View view) {
        int currentPosition = viewPager.getCurrentItem();
        viewPager.setCurrentItem(currentPosition + 1, true);
    }
}

