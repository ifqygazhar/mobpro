
package com.alfinn.listhewan.models;
import android.os.Parcel;
import android.os.Parcelable;

public class Animal implements Parcelable {
    private final String name;
    private final String description;
    private final int imageResource;

    public Animal(String name, String description, int imageResource) {
        this.name = name;
        this.description = description;
        this.imageResource = imageResource;
    }

    // Implementasi Parcelable
    protected Animal(Parcel in) {
        name = in.readString();
        description = in.readString();
        imageResource = in.readInt();
    }

    public static final Creator<Animal> CREATOR = new Creator<Animal>() {
        @Override
        public Animal createFromParcel(Parcel in) {
            return new Animal(in);
        }

        @Override
        public Animal[] newArray(int size) {
            return new Animal[size];
        }
    };

    // Getter untuk mendapatkan data hewan
    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public int getImageResource() {
        return imageResource;
    }

    // Override methods dari Parcelable
    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(description);
        dest.writeInt(imageResource);
    }
}
