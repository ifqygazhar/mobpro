package com.alfinn.listhewan;

import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.alfinn.listhewan.models.Animal;
import com.squareup.picasso.Picasso;

public class DetailActivity extends AppCompatActivity {

    private ImageButton back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_detail);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Animal animal = getIntent().getParcelableExtra("animal");
        if (animal == null) return;
        ImageView imageView = findViewById(R.id.imgAnimal);
        TextView nameTextView = findViewById(R.id.tvAnimalName);
        TextView descriptionTextView = findViewById(R.id.tvAnimalDescription);
        back = findViewById(R.id.backBtn);

        back.setOnClickListener(v -> {
            onBackPressed();
            finish();
        });

        Picasso.get().load(animal.getImageResource()).into(imageView);
        nameTextView.setText(animal.getName());
        descriptionTextView.setText(animal.getDescription());
    }
    }


